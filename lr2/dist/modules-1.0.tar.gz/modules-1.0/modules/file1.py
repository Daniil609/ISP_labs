from main import *
from serializers import *
from customSerializer import *

z = 10

def func(x, y):
    return x + y + z



class a:




